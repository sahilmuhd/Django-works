from django.apps import AppConfig


class S1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 's1'
